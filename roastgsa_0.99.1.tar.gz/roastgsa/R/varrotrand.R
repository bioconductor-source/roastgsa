
########################################################
#########  function:  varrotrand     ###################
########################################################

varrotrand <- function(obj, y, testedsizes = c(3:30,seq(32,50, by=2), seq(55,200,by=5)),
                             nrep = 200, nrot = NULL, mccores = NULL, weighting = FALSE, apenalty,
                             spenalty, psel = NULL){

    if(is.null(nrot)) nrot = attr(obj,"nrot")

    if(is.null(mccores)) mccores = attr(obj,"mccores")

    psel2  <- psel

    if(weighting){
        if(!is.null(psel2))
        {
            y <- y[psel2,]
            rownames(y) <- names(psel2)
            psel2 <- NULL
        }
    }
    k <- 1
    varrot <- sapply(testedsizes, function(k){
        print(k)

        if(weighting){
            indexaux <- lapply(1:nrep, function(o) sample(rownames(y), k))
            des <- obj$des
            lmf1  <- lmFit(y, des)
            y2 <- y  - as.matrix(lmf1$coef ) %*% t(as.matrix((des) ))

            N  <- lmf1$df.residual[1]
            ncomp  <- ifelse(N<=5,1,ifelse(N>10,3,2))

            weigths  <-  weightrgsa(y2, index= indexaux, ncomp = ncomp,
                                          apenalty = apenalty[lmf1$df.residual[1]],
                                          spenalty= spenalty[lmf1$df.residual[1]], mccores = 1)
            names(weigths)  <- names(indexaux)
        }
        else
        {
            weigths <- NULL
            if(is.null(psel2)) indexaux <- lapply(1:nrep, function(o) sample(rownames(y), k))
            else indexaux <- lapply(1:nrep, function(o) sample(names(psel2), k))

        }

        obj2 <- roastgsa(y, form = obj$form, covar = obj$covar, contrast = obj$contrast,
                     index = indexaux, nrot = nrot, mccores = mccores, weights = weigths,
                     set.statistic = obj$statistic, self.contained = obj$self.contained,
                     psel = psel2)
        obj2$res[["est"]]/obj2$res[["nes"]]
    })
    varrot <- list(varrot = varrot, testedsizes = testedsizes, nrep=nrep)
    class(varrot) <- "varrotrand"
    return(varrot)
}
