
weightrgsa <- function(y, index, ncomp = 3, apenalty = 0, spenalty= 0, mccores = 2){
    rsq <- mclapply(1:length(index), function(S){
#        print(S)
        a2  <- index[[S]]
        ye  <- t(scale(t(y[a2,])))
        nonans  <- which(!apply(is.nan(ye),1,any))
        ye  <- ye[nonans,]
        wi  <-   sapply(1:nrow(ye), function(R){
            k  <- R
            pc1  <- try(svd(scale(t(ye)[,-k],scale = FALSE),min(nrow(ye)-2,ncomp),0))
            if(class(pc1)=="try-error")
                return(NA)
            else{
                if(ncol(pc1$u)==1)
                    pc1  <-  pc1$u * pc1$d[1:ncol(pc1$u)]
                else
                    pc1  <-  pc1$u %*% diag(pc1$d[1:ncol(pc1$u)])
                return(summary(lm(ye[k,] ~  pc1))$r.squared)
                }
        })
        a1  <- rep(NA, length(a2))
        a1[nonans]  <- sqrt(wi/(1-wi) *( ncol(y)-ncomp))
        a1[is.na(a1)]  <- 1000#mean(a1,na.rm = TRUE)
        a1
    },mc.cores = mccores)
    if(length(apenalty)==1) apenalty <- rep(apenalty, length(rsq))
    if(length(spenalty)==1) spenalty <- rep(spenalty, length(rsq))

    weights1 <- lapply(1:length(index), function(i){
        aux1  <- rsq[[i]] + apenalty[i] + spenalty[i]
        as.matrix(1/(aux1 *sum(1/aux1)))
    })
    return(weights1)
}

